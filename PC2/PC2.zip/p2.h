#ifndef H_PC2
#define H_PC2

void solucion_2();

#endif