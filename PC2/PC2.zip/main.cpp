
#include <iostream>
#include <ctime>
#include "p1.h"
#include "p2.h"
#include "p3.h"

using namespace std;

//Este main corre todo seguido. El codigo esta en los .cpp files

int main(int argc, char *argv[])
{
	//Porfavor ignorar no se logro completar, revisar codigo
	//solucion_1();
	std::cout << ' ' << std::endl;
	solucion_2();
	std::cout << ' ' << std::endl;
	solucion_3();
	return 0;
}