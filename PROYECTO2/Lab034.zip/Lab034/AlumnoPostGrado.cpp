//
// Created by estan on 12/2/2021.
//

#include "AlumnoPostGrado.h"
// Ojo: Primero, se esta invocando al constructor del ancestro AlumnoPreGrado
AlumnoPostGrado::AlumnoPostGrado(const string &codigo, const string &nombre, const string &apellidoPaterno,
                                 const string &apellidoMaterno, const string &empresaTrabajo) : AlumnoPreGrado(codigo,
                                                                                                               nombre,
                                                                                                               apellidoPaterno,
                                                                                                               apellidoMaterno),
                                                                                                empresaTrabajo(
                                                                                                        empresaTrabajo) {}

const string &AlumnoPostGrado::getEmpresaTrabajo() const {
    return empresaTrabajo;
}

void AlumnoPostGrado::setEmpresaTrabajo(const string &empresaTrabajo) {
    AlumnoPostGrado::empresaTrabajo = empresaTrabajo;
}

void AlumnoPostGrado::mostrar() {
    // Invocar a metodos del ancestro
    // Sintaxis: Clase::metodo()
    AlumnoPreGrado::mostrar();
    cout <<"\t"<< empresaTrabajo<<endl;
}

AlumnoPostGrado::~AlumnoPostGrado() {
    empresaTrabajo="";
}
