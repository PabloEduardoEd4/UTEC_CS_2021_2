//
// Created by estan on 12/2/2021.
//

#ifndef LAB034_ALUMNOPREGRADO_H
#define LAB034_ALUMNOPREGRADO_H
#include <iostream>
using namespace std;

class AlumnoPreGrado {
protected:
    string codigo;
    string nombre;
    string apellidoPaterno;
    string apellidoMaterno;
public:
    // Constructor
    AlumnoPreGrado(const string &codigo, const string &nombre, const string &apellidoPaterno,
                   const string &apellidoMaterno);
    // Accesso
    const string &getCodigo() const;
    void setCodigo(const string &codigo);
    const string &getNombre() const;
    void setNombre(const string &nombre);
    const string &getApellidoPaterno() const;
    void setApellidoPaterno(const string &apellidoPaterno);
    const string &getApellidoMaterno() const;
    void setApellidoMaterno(const string &apellidoMaterno);
    // Comportamiento
    virtual void mostrar();
    // Destructor
    virtual ~AlumnoPreGrado();

};


#endif //LAB034_ALUMNOPREGRADO_H
