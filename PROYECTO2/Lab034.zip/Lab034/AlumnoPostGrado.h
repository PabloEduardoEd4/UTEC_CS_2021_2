//
// Created by estan on 12/2/2021.
//

#ifndef LAB034_ALUMNOPOSTGRADO_H
#define LAB034_ALUMNOPOSTGRADO_H
#include "AlumnoPreGrado.h"

// Establecer la relacion de Herencia
class AlumnoPostGrado: public AlumnoPreGrado{
private:
    string empresaTrabajo;
public:
    // Constructor
    AlumnoPostGrado(const string &codigo, const string &nombre, const string &apellidoPaterno,
                    const string &apellidoMaterno, const string &empresaTrabajo);
    // Acceso
    const string &getEmpresaTrabajo() const;
    void setEmpresaTrabajo(const string &empresaTrabajo);
    // Comportamiento
    void mostrar() override;
    // Destructor
    ~AlumnoPostGrado() override;

};


#endif //LAB034_ALUMNOPOSTGRADO_H
