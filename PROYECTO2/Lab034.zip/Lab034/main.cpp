#include <iostream>
#include "AlumnoPreGrado.h"
#include "AlumnoPostGrado.h"

int main() {
    // Escenario 1: Usando objeto especifico AlumnoPreGrado
    AlumnoPreGrado* a1 = new AlumnoPreGrado("a410091","Ximena","Contreras", "Gagliuffi");
    a1->mostrar();
    cout<<"\n"<<endl;
    // Escenario 2: Usando objeto especifico AlumnoPostGrado
    AlumnoPostGrado* a2 = new AlumnoPostGrado("a65252", "Carlos", "Laos", "Lu","SingularTech");
    a2->mostrar();
    cout << "Se que tengo empresa de trabajo: "<< a2->getEmpresaTrabajo()<<endl;
    cout << "\n"<<endl;
    // Escenario 3: Usando objeto generico AlumnoPreGrado
    // Ojo: Un objeto generico (declarado como instancia de la clase base) esta
    //      listo para ser usando/creado/instanciado/manipulado como cualquier instancia
    //      de una clase hija

    AlumnoPreGrado* a3 = new AlumnoPostGrado("A520045","Ber", "Bravo", "Mejia","AFP Integra");
    a3->mostrar();
    // Para tener acceso a los metodos especificos que no reconoce el objeto generico
    // se debe usar Type Casting.
    // Sintaxis:
    //  ((Tipo)variable)
    cout << "Ya me acorde que tengo empresa de trabajo: "<< ((AlumnoPostGrado *)a3)->getEmpresaTrabajo()<<endl;
    // Para ejecutar metodos que son de la clase ancestra (metodos generales), tambien
    // se usa type casting, pero a lo objetos.
    ((AlumnoPreGrado)(*a3)).mostrar();



    delete a1;
    delete a2;
    return 0;
}
