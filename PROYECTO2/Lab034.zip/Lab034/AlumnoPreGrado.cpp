//
// Created by estan on 12/2/2021.
//

#include "AlumnoPreGrado.h"

AlumnoPreGrado::AlumnoPreGrado(const string &codigo, const string &nombre, const string &apellidoPaterno,
                               const string &apellidoMaterno) : codigo(codigo), nombre(nombre),
                                                                apellidoPaterno(apellidoPaterno),
                                                                apellidoMaterno(apellidoMaterno) {}

const string &AlumnoPreGrado::getCodigo() const {
    return codigo;
}

void AlumnoPreGrado::setCodigo(const string &codigo) {
    AlumnoPreGrado::codigo = codigo;
}

const string &AlumnoPreGrado::getNombre() const {
    return nombre;
}

void AlumnoPreGrado::setNombre(const string &nombre) {
    AlumnoPreGrado::nombre = nombre;
}

const string &AlumnoPreGrado::getApellidoPaterno() const {
    return apellidoPaterno;
}

void AlumnoPreGrado::setApellidoPaterno(const string &apellidoPaterno) {
    AlumnoPreGrado::apellidoPaterno = apellidoPaterno;
}

const string &AlumnoPreGrado::getApellidoMaterno() const {
    return apellidoMaterno;
}

void AlumnoPreGrado::setApellidoMaterno(const string &apellidoMaterno) {
    AlumnoPreGrado::apellidoMaterno = apellidoMaterno;
}

void AlumnoPreGrado::mostrar() {
    cout << codigo << "\t"<<apellidoPaterno<<" "<<apellidoMaterno<<", "<<nombre;
}

AlumnoPreGrado::~AlumnoPreGrado() {
    codigo="";
    nombre="";
    apellidoPaterno="";
    apellidoMaterno="";
}
