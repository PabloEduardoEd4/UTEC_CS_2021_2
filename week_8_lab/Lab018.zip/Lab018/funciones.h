//
// Created by estan on 10/21/2021.
//

#ifndef LAB018_FUNCIONES_H
#define LAB018_FUNCIONES_H
int ingresarDimensionArreglo();
int* crearArregloDinamico(int cantidadElementos);
void imprimirArregloDinamico(int* pArreglo, int cantidadElementos);
void generarArregloMultiplos(int* pArregloOriginal, int cantidadElementos, int numero, int* &pArregloMultiplo, int &numeroMultiplos);

#endif //LAB018_FUNCIONES_H
