#include <iostream>
#include "funciones.h"

int main() {
    int cantidadElementos = ingresarDimensionArreglo();
    int* pDatos = crearArregloDinamico(cantidadElementos);
    imprimirArregloDinamico(pDatos, cantidadElementos);
    int *pMultiplo5 = nullptr, *pMultiplo7 = nullptr;
    int cantidadMultiplos5=0, cantidadMultiplos7=0;
    generarArregloMultiplos(pDatos, cantidadElementos,5,pMultiplo5, cantidadMultiplos5 );
    imprimirArregloDinamico(pMultiplo5, cantidadMultiplos5);
    generarArregloMultiplos(pDatos, cantidadElementos,7,pMultiplo7, cantidadMultiplos7 );
    imprimirArregloDinamico(pMultiplo7, cantidadMultiplos7);
    delete[] pDatos;
    delete[] pMultiplo5;
    delete[] pMultiplo7;
    return 0;
}
