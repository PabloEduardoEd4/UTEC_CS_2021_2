//
// Created by estan on 10/21/2021.
//

#include "funciones.h"
#include <iostream>
#include <ctime>
using namespace  std;

int ingresarDimensionArreglo() {
    int dimesion = 0;
    do {
        cout << "Ingrese la dimension del arreglo: ";
        cin >> dimesion;
    }while (dimesion<0);
    return dimesion;
}

int *crearArregloDinamico(int cantidadElementos) {
    int* pDatos = new int[cantidadElementos]();
    srand(time(0));
    for (int i = 0; i < cantidadElementos; ++i)
        pDatos[i]= rand()%999;
    return pDatos;
}

void imprimirArregloDinamico(int *pArreglo, int cantidadElementos) {
    cout << "[";
    for (int i = 0; i < cantidadElementos; ++i)
        cout << pArreglo[i]<<"  ";
    cout << "]"<<endl;
}

void generarArregloMultiplos(int *pArregloOriginal, int cantidadElementos, int numero, int *&pArregloMultiplo,
                             int &numeroMultiplos) {
    numeroMultiplos=0;
    for (int i = 0; i < cantidadElementos; ++i)
        if (pArregloOriginal[i]%numero==0)
            numeroMultiplos++;
    pArregloMultiplo = new int[numeroMultiplos]();
    for (int i = 0, numeroMultiplos=0; i < cantidadElementos; ++i)
        if (pArregloOriginal[i]%numero==0)
            pArregloMultiplo[numeroMultiplos++] = pArregloOriginal[i];
}
