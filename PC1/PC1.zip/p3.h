#ifndef H_PC3
#define H_PC3

void solucion3();

#endif