#ifndef H_PC1
#define H_PC1

void solucion_1();

#endif